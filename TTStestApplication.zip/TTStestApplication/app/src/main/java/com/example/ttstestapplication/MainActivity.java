package com.example.ttstestapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.util.ULocale;
import android.media.AudioManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Objects;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    private Button iv_mic;
    private TextView tv_Speech_to_text;
    private static final int REQUEST_CODE_SPEECH_INPUT = 1;
    private static final int REQUEST_CODE_SPEECH_OUTPUT = 2;
    private Button iv_voice;
    private TextToSpeech mtts;
    private String heks = "Dit werkt wel ja";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv_mic = findViewById(R.id.buttonSTT);
        tv_Speech_to_text = findViewById(R.id.textView);

        iv_mic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to text");

                try {
                    startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
                } catch (Exception e){
                    Toast.makeText(MainActivity.this, " " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

        iv_voice = findViewById(R.id.buttonTSS);

        iv_voice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
                try {
                    startActivityForResult(intent, REQUEST_CODE_SPEECH_OUTPUT);
                } catch (Exception e){
                    Toast.makeText(MainActivity.this, " " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
           super.onActivityResult(requestCode, resultCode, data);
           if(requestCode == REQUEST_CODE_SPEECH_INPUT){
               if(resultCode == RESULT_OK && data != null){
                   ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                   tv_Speech_to_text.setText(Objects.requireNonNull(result).get(0));
               }
           }

           if(requestCode == REQUEST_CODE_SPEECH_OUTPUT){
               if(resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS){
                   mtts = new TextToSpeech(this, this);
                   mtts.speak(heks, TextToSpeech.QUEUE_FLUSH, null);
               }  else {
                   Intent installIntent = new Intent();
                   installIntent.setAction(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
                   startActivity(installIntent);
               }

           }
    }

    @Override
    public void onInit(int i) {
        if(i == TextToSpeech.SUCCESS) {
            if(mtts.isLanguageAvailable(Locale.getDefault())==TextToSpeech.LANG_AVAILABLE)
            {
                mtts.setLanguage(Locale.getDefault());     
            }

        } else if (i == TextToSpeech.ERROR) {
            Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_LONG).show();
        }
    }
}